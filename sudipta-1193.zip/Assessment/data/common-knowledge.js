const quizData = {
  title: "Quize app Application"
};

const questions = [
  {
    question: "Q1.What is capital of India?",
    a: "Kolkata",
    b: "Mumbai",
    c: "Chennai",
    d: "Delhi",
    ans: "Delhi"
  },
  {
    question: "Q2.What is the national animal of India?",
    a: "Tiger",
    b: "Lion",
    c: "Horse",
    d: "Fox",
    ans: "Tiger"
  },
  {
    question: "Q3.What is the full form of HTML?",
    a: "Hello To my Land",
    b: "Hey Text Markup Language",
    c: "HyperText Makeup Language",
    d: "Hypertext Markup Language",
    ans: "Hypertext Markup Language"
  },
  {
    question: "Q4.What is the full form of CSS?",
    a: "Cascading Style Sheep",
    b: "Cascading Style Sheets",
    c: "Cartoon Style Sheet",
    d: "Cascading Super Sheets",
    ans: "Cascading Style Sheets"
  },
  {
    question: "Q5.What is the full form of HTTP?",
    a: "Hypertext Transfer Product",
    b: "Hypertext Test protocol",
    c: "HyperText Transfer Protocol",
    d: "Hey Transfer Protocol",
    ans: "HyperText Transfer Protocol"
  },
  {
    question: "Q6.What is the capital of nepal?",
    a: "Sikkim",
    b: "Bhutan",
    c: "kathmandu",
    d: "Kolkata",
    ans: "kathmandu"
  },
  {
    question: "Q7.What is the output of '2+1'?",
    a: "5",
    b: "7",
    c: "4",
    d: "3",
    ans: "3"
  },
  {
    question: "Q8.What is the full form of NCC?",
    a: "National Cadet Corps",
    b: "National Credit Corps",
    c: "National Cadet Crops",
    d: "National Cradet Corps",
    ans: "National Cadet Corps"
  },
  {
    question: "Q9.Who is the CEO of Goggle?",
    a: "Subhajit maity",
    b: "virat kohli",
    c: "Nelson Mandela",
    d: "Sunder pichai",
    ans: "Sunder pichai"
  },
  {
    question: "Q10.Who is the founder of Infosys?",
    a: "Subhajit maity",
    b: "N. R. Narayana Murthy",
    c: "Sunder pichai",
    d: "Sachin Tendulkar",
    ans: "N. R. Narayana Murthy"
  }

];

module.exports = { quizData, questions };
